#ifndef _BUTTON_H_
#define _BUTTON_H_

int button_debounce();

#endif
