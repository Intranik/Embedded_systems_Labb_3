#ifndef _LED_H_
#define _LED_H_

void LED_init(void);

uint8_t simple_ramp(void);

#endif  // _LED_H_
