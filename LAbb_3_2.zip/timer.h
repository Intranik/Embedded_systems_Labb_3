#ifndef _TIMER_H_
#define _TIMER_H_

int time;
int oldTime;

void timer_init();

void timer2_init(void);

#endif